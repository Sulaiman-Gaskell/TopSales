﻿using System;
using System.IO;
using System.Runtime.ConstrainedExecution;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                // gets data from user
                Console.Write("Enter item name: ");
                string item = Console.ReadLine();
                Console.Write("Enter sales from last month: ");
                string m1 = Console.ReadLine();
                Console.Write("Enter sales from the month before the last ");
                string m2 = Console.ReadLine();

                //writes details to file
                File.AppendAllText(@"C:\Users\sulai\source\repos\TopSales\TopSales\Items.txt"
, item + "," + m1 + "," + m2 + Environment.NewLine);

                //Asks user if they want to add more data
                Console.WriteLine("Add more data (y/n)?: ");
                string again = Console.ReadLine();
                if (again == "n") { break; }

            }


            // Initialize a Dictionary to store the data

            SortedDictionary<string, List<string>> data = new SortedDictionary<string, List<string>>();

            // Provide the path to the text file
            string filePath = @"C:\Users\sulai\source\repos\TopSales\TopSales\Items.txt";

            try
            {
                // Read all lines from the text file
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    // Split the line into an array of values using ',' as the delimiter
                    string[] values = line.Split(',');

                    if (values.Length > 0)
                    {
                        // The first item on each row is the key
                        string key = values[0];

                        // The rest of the items on the row are values
                        List<string> rowValues = new List<string>();
                        for (int i = 1; i < values.Length; i++)
                        {
                            rowValues.Add(values[i]);
                        }

                        // Add the key and values to the dictionary
                        data[key] = rowValues;
                    }
                }

               

                // Case 1
                foreach (var entry in data)
                {
                    // Compares the two values for each entry
                    int v0 = Convert.ToInt32(entry.Value[0]);
                    int v1 = Convert.ToInt32(entry.Value[1]);

                    if (v0 > v1) 
                    {
                        Console.WriteLine($"Max sale for {entry.Key} is {entry.Value[0]}");
                    }
                    else
                    {
                        Console.WriteLine($"Max sale for {entry.Key} is {entry.Value[1]}");
                    }
                }

                
                // Case 2



            }
            catch (Exception e)
            {
                Console.WriteLine($"An error occurred: {e.Message}");
            }



        }
    }
}